<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_congreso
 *
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Congreso Controller
 *

 */
class CongresoControllerAuthor extends JControllerForm
{

	protected $default_view = 'author';
}