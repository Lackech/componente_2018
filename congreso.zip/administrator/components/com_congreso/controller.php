<?php
/**
 * @package    congreso
 *
 * @author     achacon <your@email.com>
 * @copyright  A copyright
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       http://your.url.com
 */

use Joomla\CMS\MVC\Controller\BaseController;

defined('_JEXEC') or die;

/**
 * Congreso Controller.
 *
 * @package  congreso
 * @since    1.0
 */
class CongresoController extends BaseController
{

	/**
	 * The default view for the display method.
	 *
	 * @var string
	 */
	protected $default_view = 'congreso';
}
