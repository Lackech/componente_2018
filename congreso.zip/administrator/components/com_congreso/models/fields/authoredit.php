<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

JFormHelper::loadFieldClass('list');

class JFormFieldAuthoredit extends JFormFieldList {

	protected $type = 'Authoredit';

	public function getOptions() {

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('#__author.name')->from('#__author');
		$rows = $db->setQuery($query)->loadObjectlist();
		foreach($rows as $row){
			$options[] = $row->name;
		}
		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);
		return $options;
	}
}